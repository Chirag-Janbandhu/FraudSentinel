from Fraudsentinel.logger import logger, get_logger

__all__ = ["logger", "get_logger"]
